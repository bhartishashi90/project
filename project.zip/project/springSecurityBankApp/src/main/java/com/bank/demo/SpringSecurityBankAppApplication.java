package com.bank.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityBankAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityBankAppApplication.class, args);
	}

}
