package com.bank.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bank.demo.entity.Account;
import com.bank.demo.entity.Bank;
import com.bank.demo.entity.TransInfo;
import com.bank.demo.exception.AccountNotfoundException;
import com.bank.demo.service.IBankService;

@RestController
public class BankController {

	@Autowired
	private IBankService iBankService;

	@RequestMapping(value = "/Bank/{id}", method = RequestMethod.PUT)
	public ResponseEntity<Object> saveBankDetails(@PathVariable("id") String id, @RequestBody Account account) {
		if (id == null)
			throw new AccountNotfoundException();
		Bank bank = new Bank();
		bank.setBName("HDFC");
		bank.setBAddress("Bangalore");
		iBankService.saveBankDetails(bank);
		return new ResponseEntity<>("Bank details is saved successfully", HttpStatus.OK);
	}
	
	@RequestMapping(value = "/dashBoardBankDetails/{id}", method = RequestMethod.PUT)
	public Account dashBoardBankDetails(@PathVariable("id") String id, @RequestBody Account account) {
		if (id == null)
			throw new AccountNotfoundException();
		int acid=0;
		try {
			acid=Integer.parseInt(id);
			return iBankService.getDashBoardDetails(acid);
		} catch (Exception e) {
			throw new AccountNotfoundException();
		}
		
	}
	
	@RequestMapping(value = "/saveTrans/{id}", method = RequestMethod.PUT)
	public TransInfo saveTrans(@PathVariable("id") String id, @RequestBody TransInfo trans) {
		if (id == null)
			throw new AccountNotfoundException();
		int acid=0;
		//trans.getAccount().getAccId();
		try {
			acid=Integer.parseInt(id);
			trans.getAccount().setAccId(acid);
			return iBankService.saveTransInfoDetails(trans);
		} catch (Exception e) {
			throw new AccountNotfoundException();
		}
		
	}

}
