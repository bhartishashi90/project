package com.bank.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bank.demo.dao.IAccountDao;
import com.bank.demo.dao.IBankDao;
import com.bank.demo.dao.ITransDao;
import com.bank.demo.entity.Account;
import com.bank.demo.entity.Bank;
import com.bank.demo.entity.TransInfo;

@Service
public class BankService implements IBankService {
	@Autowired
	private IBankDao iBankDao;

	@Autowired
	private IAccountDao iAccountDao;

	@Autowired
	private ITransDao iTransDao;

	@Override
	public Bank saveBankDetails(Bank bk) {
		return iBankDao.save(bk);
	}

	@Override
	public Account saveAccountDetails(Account acc) {
		return iAccountDao.save(acc);
	}

	@Override
	public TransInfo saveTransInfoDetails(TransInfo trans) {
		return iTransDao.save(trans);
	}

	@Override
	public Account getDashBoardDetails(int accId) {
		return iAccountDao.getDashBoardDetails(accId);
	}

}
