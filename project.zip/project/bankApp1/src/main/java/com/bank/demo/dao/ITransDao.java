package com.bank.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bank.demo.entity.TransInfo;

public interface ITransDao extends JpaRepository<TransInfo, Integer>{

}
