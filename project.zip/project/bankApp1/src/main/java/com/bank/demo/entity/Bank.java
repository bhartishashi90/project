package com.bank.demo.entity;

import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "BANK")
@Getter
@Setter
public class Bank {
	@Id
	@Column(name = "bid")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int bid;
	@Column(name = "bName")
	private String bName;
	@Column(name = "bAddress")
	private String bAddress;
	@OneToMany(mappedBy="accId")
	private List<Account> account;
}
