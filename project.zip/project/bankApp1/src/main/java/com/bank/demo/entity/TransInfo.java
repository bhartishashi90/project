package com.bank.demo.entity;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "TRANS_INFO")
@Getter
@Setter
public class TransInfo {
	@Id
	@Column(name = "transId")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int transId;
	@Column(name = "crdAmt")
	private double crdAmt;
	@Column(name = "debtAmt")
	private double debtAmt;
	@Column(name = "transDate")
	private Date transDate;
	@ManyToOne
	@JoinColumn(name="accId", nullable=false)
	private Account account;
}
