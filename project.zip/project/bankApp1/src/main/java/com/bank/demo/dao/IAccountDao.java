package com.bank.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.bank.demo.entity.Account;

public interface IAccountDao extends JpaRepository<Account, Integer>{
	 @Query(value = "SELECT e FROM Account e ")
	   public Account getDashBoardDetails(int accid);
}
