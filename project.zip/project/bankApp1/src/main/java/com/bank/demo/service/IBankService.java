package com.bank.demo.service;

import com.bank.demo.entity.Account;
import com.bank.demo.entity.Bank;
import com.bank.demo.entity.TransInfo;

public interface IBankService {
	public Bank saveBankDetails(Bank bk);
	public Account saveAccountDetails(Account acc);
	public TransInfo saveTransInfoDetails(TransInfo trans);
	public Account getDashBoardDetails(int accId);
	
}
