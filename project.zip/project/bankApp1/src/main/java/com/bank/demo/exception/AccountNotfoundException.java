package com.bank.demo.exception;

public class AccountNotfoundException extends RuntimeException {
	private static final long serialVersionUID = 1L;
}
