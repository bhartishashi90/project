package com.bank.demo.entity;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;


@Entity
@Table(name="USERS_BNK")
@Getter
@Setter
public class User {
	@Id
	@Column(name="userId")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int userId;
	@Column(name="userName")
	private String userName;
	@Column(name="status")
	private String status;
	@Column(name="createDate")
	private Date createDate;
	@Column(name="sttsDate")
	private Date sttsDate;

}
